package com.example.connect4

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.graphics.Color
import android.graphics.Paint
import android.app.AlertDialog
import android.view.Gravity
import android.widget.TextView

class Connect4 (context: Context, attrs: AttributeSet? = null) : View(context, attrs), GestureDetector.OnGestureListener{
    private val gestureDetector = GestureDetector(context, this)

    private val columnCount = 7
    private val rowCount = 6
    private val gridPaint = Paint()
    private val textPaint = Paint()
    private val tokenPaint = Paint()
    private val playerPaint = Paint()

    private var currentPlayer: Int = 1 //player 1 & player 2
    private val player1Color = Color.YELLOW
    private val player2Color = Color.RED

    private var bigSquare = 0
    private var squareSize = 0
    private var left = 0f
    private var top = 0f
    private var bottom = 0f
    private var right = 0f
    private var board: Array<IntArray> = Array(rowCount){IntArray(columnCount)}

    init {
        for (row in 0 until rowCount){
            for (col in 0 until columnCount){
                board[row][col] = 0
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bigSquare = w.coerceAtMost(h)
        squareSize = (w.coerceAtMost(h) / columnCount)

        left = ((width - bigSquare) / 2).toFloat()
        top = ((height - bigSquare) / 2).toFloat()
        right = left + bigSquare
        bottom = top + bigSquare

    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawGrid(canvas)
        drawText(canvas)
    }

    private fun drawGrid(canvas: Canvas) {
        gridPaint.color = Color.BLACK
        gridPaint.strokeWidth = 4f
        gridPaint.style = Paint.Style.STROKE

        // Draw horizontal grid lines
        for (i in 0 until rowCount + 1) {
            val linePosition = i * squareSize + top
            canvas.drawLine(left, linePosition, right, linePosition, gridPaint)
        }

        // Draw vertical grid lines
        for (i in 0 until columnCount + 1) {
            val linePosition = i * squareSize + left
            canvas.drawLine(linePosition, top, linePosition, bottom - squareSize, gridPaint)
        }

        for (row in 0 until rowCount){
            for (col in 0 until columnCount){
                if (board[row][col] != 0){
                    tokenPaint.color = if (board[row][col] == 1) player1Color else player2Color
                    tokenPaint.style = Paint.Style.FILL
                    val centerX = col * squareSize + left + squareSize /2
                    val centerY = row * squareSize + top + squareSize /2
                    canvas.drawCircle(centerX,centerY,(squareSize/2.5).toFloat(), tokenPaint)
                }
            }
        }

    }

    private fun drawText(canvas: Canvas) {
        textPaint.color = Color.BLACK
        textPaint.textSize = squareSize.toFloat() / 1.5f
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.style = Paint.Style.FILL_AND_STROKE

        val playerText = if (currentPlayer == 1) "PLAYER 1" else "PLAYER 2"
        canvas.drawText(playerText, right / 2, bottom, textPaint)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if(gestureDetector.onTouchEvent(event)) {
            return true
        }
        return super.onTouchEvent(event)
    }

    override fun onDown(e: MotionEvent): Boolean {
        return true
    }

    override fun onShowPress(e: MotionEvent) {

    }

    override fun onSingleTapUp(e: MotionEvent): Boolean {
        e.let {
            val row = ((it.y - top.toFloat()) / squareSize).toInt()
            val col = ((it.x - left.toFloat())/ squareSize).toInt()

            if (row in 0 until rowCount && col in 0 until columnCount) {
                dropToken(col)
                if (checkForWin()){
                    announceWin()
                }
                if (stalemate()){
                    resetGame()
                }
                invalidate()
            }
        }
        return true
    }

    private fun stalemate(): Boolean {
        for (row in 0 until rowCount){
            for (col in 0 until columnCount){
                if (board[row][col] == 0){
                    return false
                }
            }
        }
        return true
    }

    private fun announceWin() {
        val alertDialog: AlertDialog
        val message = TextView(context)

        message.text = "PLAYER $currentPlayer WON"
        message.gravity = Gravity.CENTER

        val builder = AlertDialog.Builder(context)
        builder.apply {
            setTitle("WINNER")
            setView(message)
            setPositiveButton("Reset") { dialog, _, ->
                resetGame()
                dialog.dismiss()
            }
        }
        alertDialog = builder.create()
        alertDialog.show()
    }

    private fun resetGame() {
        for (row in 0 until rowCount){
            for (col in 0 until columnCount){
                board[row][col] = 0
            }
        }
        invalidate()
        currentPlayer = 1
    }

    private fun checkForWin() : Boolean {
        return checkHorizontalWin() || checkVerticalWin() || checkDiagonalWin()
    }

    private fun checkDiagonalWin(): Boolean {
        for (row in 3 until rowCount){
            for (col in 0 until columnCount - 3){
                val token = board[row][col]
                if (token != 0 && token == board[row - 1][col + 1] && token == board[row - 2][col + 2] && token == board[row - 3][col + 3]){
                    return true
                }
            }
        }

        for (row in 0 until rowCount - 3){
            for (col in 0 until columnCount - 3){
                val token = board[row][col]
                if (token != 0 && token == board[row + 1][col + 1] && token == board[row + 2][col + 2] && token == board[row + 3][col + 3]){
                    return true
                }
            }
        }

        return false
    }

    private fun checkVerticalWin(): Boolean {
        for (col in 0 until columnCount){
            for (row in 0 until rowCount - 3){
                val token = board[row][col]
                if (token != 0 && token == board[row + 1][col] && token == board[row + 2][col] && token == board[row + 3][col]){
                    return true
                }
            }
        }
        return false
    }

    private fun checkHorizontalWin(): Boolean {
        for (row in 0 until rowCount){
            for (col in 0 until columnCount - 3){
                val token = board[row][col]
                if (token != 0 && token == board[row][col + 1] && token == board[row][col + 2] && token == board[row][col + 3]){
                    return true
                }
            }
        }
        return false
    }

    private fun dropToken(column: Int) {
        val targetRow = findEmptyRow(column)
        if (targetRow != -1){
            board[targetRow][column] = currentPlayer
            currentPlayer = (currentPlayer % 2) + 1
        }
    }

    private fun findEmptyRow(column: Int): Int {
        for (row in rowCount - 1 downTo 0 ){
            if (board[row][column] == 0){
                return row
            }
        }
        return -1
    }

    override fun onScroll(
        e1: MotionEvent?,
        e2: MotionEvent,
        distanceX: Float,
        distanceY: Float
    ): Boolean {
        return false
    }

    override fun onLongPress(e: MotionEvent) {

    }

    override fun onFling(
        e1: MotionEvent?,
        e2: MotionEvent,
        velocityX: Float,
        velocityY: Float
    ): Boolean {
        return false
    }

}