package com.example.barcodescanner

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.barcodescanner.databinding.ActivityCameraBinding
import com.google.common.util.concurrent.ListenableFuture
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

class CameraActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCameraBinding

    //used to select a camera
    private lateinit var cameraSelector: CameraSelector

    //used to bind the lifecycle of our camera
    private lateinit var processCameraProvider: ProcessCameraProvider

    //used as listener for completion from executor
    private lateinit var cameraProviderFuture: ListenableFuture<ProcessCameraProvider>

    //used to display camera preview on screen
    private lateinit var cameraPreview: Preview

    //used to acquire images from the camera
    private lateinit var imageAnalysis: ImageAnalysis

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener(){
            onBackPressed()
        }

        //select back camera
        cameraSelector = CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .build()

        //set-up Listener and bind it to the preview
        cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            processCameraProvider = cameraProviderFuture.get()
            bindCameraPreview()
            bindImageAnalyser()
        }, ContextCompat.getMainExecutor(this)
        )
    }

    private fun bindImageAnalyser() {
        val barcodeScanner: BarcodeScanner = BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                    Barcode.FORMAT_QR_CODE,
                    Barcode.FORMAT_AZTEC,
                    Barcode.FORMAT_UPC_A,
                    Barcode.FORMAT_UPC_E
                    )
                .enableAllPotentialBarcodes()
                .build()
        )

        imageAnalysis = ImageAnalysis.Builder()
            .setTargetRotation(binding.previewCam.display.rotation)
            .build()

        val cameraExecutor = Executors.newSingleThreadExecutor()

        imageAnalysis.setAnalyzer(cameraExecutor){ imageProxy ->
            imageAnalyser(barcodeScanner, imageProxy)
        }

        processCameraProvider.bindToLifecycle(this, cameraSelector, imageAnalysis)
    }


    @SuppressLint("UnsafeOptInUsageError")
    private fun imageAnalyser(barcodeScanner: BarcodeScanner, imageProxy: ImageProxy){
        val mediaImage = imageProxy.image
        if (mediaImage != null){
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

            barcodeScanner.process(image)
                .addOnSuccessListener {
                    if (it.isNotEmpty()){
                        onScan?.invoke(it)
                        onScan = null
                        finish()
                    }
                }.addOnFailureListener{
                    //handle exceptions
                }.addOnCompleteListener{
                    imageProxy.close()
                }
        }
    }

    private fun bindCameraPreview(){
        cameraPreview = Preview.Builder()
            .setTargetRotation(binding.previewCam.display.rotation)
            .build()

        //setting the surface for the camera which will let the camera know it is ready for use in its cycle
        cameraPreview.setSurfaceProvider(binding.previewCam.surfaceProvider)

        //set the lifeCycle of the camera to this Activity
        processCameraProvider.bindToLifecycle(this, cameraSelector, cameraPreview)
    }

    //object used to communicate between the two activities
    companion object {
        private var onScan: ((barcodes: List<Barcode>) -> Unit)? = null
        fun startBarcode(context: Context, onScan: (barcodes: List<Barcode>) -> Unit) {
            this.onScan = onScan
            Intent(context, CameraActivity::class.java).also{
                context.startActivity(it)
            }
        }
    }
}