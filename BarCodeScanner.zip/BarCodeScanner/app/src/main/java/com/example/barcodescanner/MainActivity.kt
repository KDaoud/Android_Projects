package com.example.barcodescanner

import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.barcodescanner.databinding.ActivityMainBinding
import com.google.mlkit.vision.barcode.common.Barcode
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val cameraPermission = android.Manifest.permission.CAMERA
    private lateinit var binding: ActivityMainBinding
    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if(it){
            startBarcode()
        }
    }

    private lateinit var cameraExecutor: ExecutorService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener{
            startCamera()
            try {
                binding.qrImage.setImageDrawable(null)
            }catch(e:IOException){
                e.printStackTrace()
            }

        }

    }

    private fun startCamera() {
        if (isPermissionGranted(cameraPermission)){
            startBarcode()
        }else{
            requestCameraPermission()
        }
    }

    private fun requestCameraPermission() {
        when {
            shouldShowRequestPermissionRationale(cameraPermission) -> {
                cameraPermissionRequest {
                    openPermissionSetting()
                }
            }else -> {
                requestPermissionLauncher.launch(cameraPermission)
            }
        }
    }

    //call the startBarcode from CameraActivity
    private fun startBarcode(){
        CameraActivity.startBarcode(this){
            it.forEach{barcode ->
                val rawValue = barcode.rawValue
                when (barcode.valueType) {
                    Barcode.TYPE_WIFI -> {
                        val ssid = barcode.wifi!!.ssid
                        val password = barcode.wifi!!.password
                        val type = barcode.wifi!!.encryptionType

                        binding.barcodeType.text = "WIFI"
                        binding.barcodeContent.text = "$ssid \n$password \n$type"

                    }
                    Barcode.TYPE_URL -> {
                        val title = barcode.url!!.title
                        val url = barcode.url!!.url

                        binding.barcodeType.text = "URL"
                        binding.barcodeContent.text = "$title \n$url"
                    }
                    else -> {
                        binding.barcodeType.text = "Other"
                        binding.barcodeContent.text = rawValue.toString()
                    }
                }
            }
        }
    }
}