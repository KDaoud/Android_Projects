package com.example.apod

import android.app.DatePickerDialog
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.android.volley.Request
import com.android.volley.toolbox.Volley
import com.android.volley.RequestQueue
import com.android.volley.toolbox.ImageRequest
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonObjectRequest
import java.util.Calendar


class MainActivity : ComponentActivity() {
    private lateinit var requestQueue: RequestQueue
    private lateinit var imageView: ImageView
    private var currentDate = "2024-01-01"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestQueue = Volley.newRequestQueue(this)
        imageView = findViewById(R.id.imageView)

        val datePicker: Button = findViewById(R.id.datePicker)
        val fetchButton: Button = findViewById(R.id.button)

        // Set onClickListener for the button to show DatePickerDialog
        datePicker.setOnClickListener {
            showDatePickerDialog()
        }

        fetchButton.setOnClickListener {
            fetchApodInfo(currentDate)
        }
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                currentDate = "$selectedYear-${selectedMonth + 1}-$selectedDay"
            },
            year,
            month,
            dayOfMonth
        )
        datePickerDialog.show()
    }

    private fun fetchApodInfo(date: String) {
        val title = findViewById<TextView>(R.id.imageTitle)
        val copyright = findViewById<TextView>(R.id.imageCopyright)
        val desc = findViewById<TextView>(R.id.imageDescription)
        var imgUrl = ""

        title.text = "Fetching"
        copyright.text = ""
        desc.text = ""

        val apiUrl = "https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&date=$date"

        val jsonRequest = JsonObjectRequest(
            Request.Method.GET, apiUrl, null,
            { response ->
                // Parse JSON response
                title.text = response.getString("title")
                desc.text = response.getString("explanation")
                imgUrl = response.getString("url")
                loadImage(imgUrl)
                if (response.has("copyright")) {
                    copyright.text = response.getString("copyright")
                } else {
                    copyright.text = ""
                }},
            { error ->
                // what to do if things fail
                //desc.text = "That didn't work: ${error.localizedMessage}"
                handleError(error)
            }
        )
        //loadImage(imgUrl)
        requestQueue.add(jsonRequest)

    }

    private fun loadImage(imgUrl: String) {
        val imageRequest = ImageRequest(
            imgUrl,
            { response ->
                // Set the fetched image to ImageView
                imageView.setImageBitmap(response)
            },
            0,
            0,
            ImageView.ScaleType.CENTER_INSIDE,
            Bitmap.Config.RGB_565,
            {
                // Handle error
                handleError(it)
            })

        // Add the image request to the RequestQueue.
        requestQueue.add(imageRequest)
    }

    private fun handleError(error: VolleyError)
    {
        Log.e("APOD", "Error: ${error.message}")
        Toast.makeText(this, "Failed to fetch. Please ensure you have a valid date.", Toast.LENGTH_SHORT).show()
    }
}
