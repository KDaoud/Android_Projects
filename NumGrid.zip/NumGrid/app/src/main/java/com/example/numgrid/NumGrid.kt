package com.example.numgrid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class NumGrid (context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val bigSquarePaint = Paint()
    private val gridPaint = Paint()
    private val textPaint = Paint()
    private val gridSize = 9
    private var bigSquareSize = 0
    private var squareSize = 0

    private var left = 0
    private var top = 0
    private var right = 0
    private var bottom = 0

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // Calculate the size of each square dynamically based on the size of the view
        bigSquareSize = w.coerceAtMost(h)
        squareSize = w.coerceAtMost(h) / gridSize

        left = (width - bigSquareSize) / 2
        top = (height - bigSquareSize) / 2
        right = left + bigSquareSize
        bottom = top + bigSquareSize
    }



    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawGrid(canvas)
        drawText(canvas)
    }

    private fun drawGrid(canvas: Canvas) {
        gridPaint.color = Color.BLACK
        gridPaint.strokeWidth =2f
        gridPaint.style = Paint.Style.STROKE

        // Draw horizontal grid lines
        for (i in 0 until gridSize + 1)
        {
            val linePosition = i * squareSize.toFloat() + top.toFloat()
            canvas.drawLine(left.toFloat(), linePosition, right.toFloat(), linePosition, gridPaint)
        }

        // Draw vertical grid lines
        for (i in 0 until gridSize + 1)
        {
            val linePosition = i * squareSize.toFloat() + left.toFloat()
            canvas.drawLine(linePosition, top.toFloat(), linePosition, bottom.toFloat(), gridPaint)
        }
    }

    private fun drawText(canvas: Canvas) {
        textPaint.color = Color.BLACK
        textPaint.textSize = squareSize.toFloat() / 1.5f
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.style = Paint.Style.FILL_AND_STROKE


        for (i in 0 until gridSize)
        {
            for (j in 0 until gridSize)
            {
                val text = "${0}"
                val x = j * squareSize + squareSize / 2
                val y = i * squareSize + squareSize / 2 - (textPaint.descent() + textPaint.ascent()) / 2
                canvas.drawText(text, x.toFloat() + left.toFloat(), y.toFloat() + top.toFloat(), textPaint)
            }
        }
    }

}

