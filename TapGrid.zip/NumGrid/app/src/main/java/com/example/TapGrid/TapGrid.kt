package com.example.TapGrid

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View

class TapGrid (context: Context, attrs: AttributeSet? = null) : View(context, attrs), GestureDetector.OnGestureListener {
    private val gridPaint = Paint()
    private val textPaint = Paint()
    private val gridSize = 9
    private var bigSquareSize = 0
    private var squareSize = 0

    private var left = 0
    private var top = 0
    private var right = 0
    private var bottom = 0

    private val gridData = Array(gridSize) {IntArray(gridSize)}

    private val gestureDetector = GestureDetector(context, this)

    // initialize grid to 0s
    init {
        for (i in 0 until gridSize){
            for (j in 0 until gridSize) {
                gridData[i][j] = 0
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // Calculate the size of each square dynamically based on the size of the view
        bigSquareSize = w.coerceAtMost(h)
        squareSize = w.coerceAtMost(h) / gridSize

        left = (width - bigSquareSize) / 2
        top = (height - bigSquareSize) / 2
        right = left + bigSquareSize
        bottom = top + bigSquareSize
    }



    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawGrid(canvas)
        drawText(canvas)
    }

    private fun drawGrid(canvas: Canvas) {
        gridPaint.color = Color.BLACK
        gridPaint.strokeWidth =2f
        gridPaint.style = Paint.Style.STROKE

        // Draw horizontal grid lines
        for (i in 0 until gridSize + 1)
        {
            val linePosition = i * squareSize.toFloat() + top.toFloat()
            canvas.drawLine(left.toFloat(), linePosition, right.toFloat(), linePosition, gridPaint)
        }

        // Draw vertical grid lines
        for (i in 0 until gridSize + 1)
        {
            val linePosition = i * squareSize.toFloat() + left.toFloat()
            canvas.drawLine(linePosition, top.toFloat(), linePosition, bottom.toFloat(), gridPaint)
        }
    }

    private fun drawText(canvas: Canvas) {
        textPaint.color = Color.BLACK
        textPaint.textSize = squareSize.toFloat() / 1.5f
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.style = Paint.Style.FILL_AND_STROKE


        for (i in 0 until gridSize)
        {
            for (j in 0 until gridSize)
            {
                val x = j * squareSize + squareSize / 2
                val y = i * squareSize + squareSize / 2 - (textPaint.descent() + textPaint.ascent()) / 2
                canvas.drawText(gridData[i][j].toString(), x.toFloat() + left.toFloat(), y.toFloat() + top.toFloat(), textPaint)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if(gestureDetector.onTouchEvent(event)) {
            return true
        }
        return super.onTouchEvent(event)
    }

    override fun onDown(p0: MotionEvent): Boolean {
        return true
    }

    override fun onShowPress(p0: MotionEvent) {

    }

    override fun onSingleTapUp(p0: MotionEvent): Boolean {
        p0.let {
            val row = ((it.y - top.toFloat()) / squareSize).toInt()
            val col = ((it.x - left.toFloat())/ squareSize).toInt()

            if (row in 0 until gridSize && col in 0 until gridSize) {
                gridData[row][col]++

                if (gridData[row][col] > 9){
                    gridData[row][col] = 0
                }

                invalidate()
            }
        }
        return true
    }

    override fun onScroll(e1: MotionEvent?, p0: MotionEvent, p2: Float, p3: Float): Boolean {
        return false
    }

    override fun onLongPress(p0: MotionEvent) {

    }

    override fun onFling(e1: MotionEvent?, p0: MotionEvent, p2: Float, p3: Float): Boolean {
        return false
    }
}

